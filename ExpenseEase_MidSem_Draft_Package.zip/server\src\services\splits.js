export function equalSplits(amount, userIds) {
  if (!Number.isInteger(amount) || amount <= 0 || !userIds?.length)
    throw new Error("A positive amount and participants are required");
  const sorted = [...userIds].sort((a, b) => a - b);
  const base = Math.floor(amount / sorted.length);
  let remainder = amount % sorted.length;
  return sorted.map((userId) => ({
    userId,
    sharePaise: base + (remainder-- > 0 ? 1 : 0),
  }));
}
export function exactSplits(amount, splits) {
  if (
    !splits?.length ||
    splits.some((s) => !Number.isInteger(s.sharePaise) || s.sharePaise < 0) ||
    splits.reduce((n, s) => n + s.sharePaise, 0) !== amount
  )
    throw new Error("Exact shares must sum to total");
  return splits.map((s) => ({ ...s }));
}
export function percentSplits(amount, splits) {
  if (
    !splits?.length ||
    splits.reduce((n, s) => n + s.percent, 0) !== 100 ||
    splits.some((s) => !Number.isInteger(s.percent) || s.percent < 0)
  )
    throw new Error("Percent values must sum to exactly 100");
  const preliminary = splits.map((s) => ({
    ...s,
    sharePaise: Math.floor((amount * s.percent) / 100),
  }));
  let left = amount - preliminary.reduce((n, s) => n + s.sharePaise, 0);
  for (const s of preliminary.sort((a, b) => a.userId - b.userId))
    if (left-- > 0) s.sharePaise++;
  return preliminary;
}
export function calculateSplits(amount, splitType, participants) {
  if (splitType === "EQUAL")
    return equalSplits(
      amount,
      participants.map((p) => p.userId),
    );
  if (splitType === "EXACT") return exactSplits(amount, participants);
  if (splitType === "PERCENT") return percentSplits(amount, participants);
  throw new Error("Invalid split type");
}
